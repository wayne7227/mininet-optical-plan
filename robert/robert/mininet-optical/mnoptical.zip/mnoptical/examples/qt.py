import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QLabel, QStackedWidget, QGridLayout, QScrollArea
import subprocess

class CalculatorApp(QWidget):
    def __init__(self):
        super().__init__()

        self.init_ui()

    def init_ui(self):
        self.stacked_widget = QStackedWidget(self)

        # Page 1
        page1_layout = QVBoxLayout()

        para_a_label_page1 = QLabel("span:", self)
        para_a_edit_page1 = QLineEdit(self)
        para_b_label_page1 = QLabel("roadm_insertion_loss:", self)
        para_b_edit_page1 = QLineEdit(self)
        para_c_label_page1 = QLabel("numAmp:", self)
        para_c_edit_page1 = QLineEdit(self)
        para_d_label_page1 = QLabel("boost_target_gain:", self)
        para_d_edit_page1 = QLineEdit(self)
        para_e_label_page1 = QLabel("BER:", self)
        para_e_edit_page1 = QLineEdit(self)

        page1_layout.addWidget(para_a_label_page1)
        page1_layout.addWidget(para_a_edit_page1)
        page1_layout.addWidget(para_b_label_page1)
        page1_layout.addWidget(para_b_edit_page1)
        page1_layout.addWidget(para_c_label_page1)
        page1_layout.addWidget(para_c_edit_page1)
        page1_layout.addWidget(para_d_label_page1)
        page1_layout.addWidget(para_d_edit_page1)
        page1_layout.addWidget(para_e_label_page1)
        page1_layout.addWidget(para_e_edit_page1)

        # unlinear btn
        do_unilinear2_button_page1 = QPushButton('do unilinear2', self)

        do_unilinear2_button_page1.clicked.connect(
            lambda: self.do_unilinear2_btn(
                para_a_edit_page1.text(),
                para_b_edit_page1.text(),
                para_c_edit_page1.text(),
                para_d_edit_page1.text())
                )

        page1_layout.addWidget(do_unilinear2_button_page1)
        
        # simulate btn
        do_simulate_button_page1 = QPushButton('do simulate', self)

        do_simulate_button_page1.clicked.connect(
            lambda: self.do_simulate_btn(
                para_a_edit_page1.text(),
                para_b_edit_page1.text(),
                para_e_edit_page1.text())
                )

        page1_layout.addWidget(do_simulate_button_page1)

        page1 = QWidget(self)
        page1.setLayout(page1_layout)


        # Page 3
        page3_layout = QVBoxLayout()

        self.var1_label_page3 = QLabel("boost_target_gain:", self)
        self.var1_ans_page3 = QLabel("", self)
        self.var2_label_page3 = QLabel("numAmp:", self)
        self.var2_ans_page3 = QLabel("", self)
        self.var3_label_page3 = QLabel("t1-gosnr:", self)
        self.var3_ans_page3 = QLabel("", self)
        self.var4_label_page3 = QLabel("t2-gosnr:", self)
        self.var4_ans_page3 = QLabel("", self)
        self.var5_label_page3 = QLabel("t1-ber:", self)
        self.var5_ans_page3 = QLabel("", self)
        self.var6_label_page3 = QLabel("t2-ber:", self)
        self.var6_ans_page3 = QLabel("", self)
        

        page3_layout.addWidget(self.var1_label_page3)
        page3_layout.addWidget(self.var1_ans_page3)
        page3_layout.addWidget(self.var2_label_page3)
        page3_layout.addWidget(self.var2_ans_page3)
        page3_layout.addWidget(self.var3_label_page3)
        page3_layout.addWidget(self.var3_ans_page3)
        page3_layout.addWidget(self.var4_label_page3)
        page3_layout.addWidget(self.var4_ans_page3)
        page3_layout.addWidget(self.var5_label_page3)
        page3_layout.addWidget(self.var5_ans_page3)
        page3_layout.addWidget(self.var6_label_page3)
        page3_layout.addWidget(self.var6_ans_page3)
        

        page3 = QWidget(self)
        page3.setLayout(page3_layout)

        # Page 4
        self.page4_layout = QGridLayout()
        # self.generate_page4_ui(page4_layout, 3)  # 3 is an example, replace with your calculated 'n'

        self.page4 = QWidget(self)
        self.page4.setLayout(self.page4_layout)

        # Add pages to stacked widget
        self.stacked_widget.addWidget(page1)
        # self.stacked_widget.addWidget(page2)
        self.stacked_widget.addWidget(page3)
        self.stacked_widget.addWidget(self.page4)

        # Next and Previous buttons
        next_button = QPushButton('下一頁', self)
        next_button.clicked.connect(self.next_page)

        prev_button = QPushButton('上一頁', self)
        prev_button.clicked.connect(self.prev_page)

        # Main layout
        main_layout = QVBoxLayout()
        main_layout.addWidget(self.stacked_widget)
        main_layout.addWidget(prev_button)
        main_layout.addWidget(next_button)

        self.setLayout(main_layout)

        self.setWindowTitle('多頁計算器')
        self.setGeometry(300, 300, 900, 1200)

    def do_unilinear2_btn(self, length, roadm_insertion_loss, numAmp, boost_target_gain):

        shell_script_path = 'test_unilear2.sh'

        parameters = [length, roadm_insertion_loss, numAmp, boost_target_gain]

        try:
            subprocess.run(['sh', shell_script_path] + parameters, check=True)

            with open('result1.txt', 'r') as file:
                line = file.readline()

            values = line.split()

            # Assign values to variables
            var1 = values[0]
            var2 = values[1]
            var3 = values[2]
            var4 = values[3]
            var5 = values[4]
            var6 = values[5]

            self.var1_ans_page3.setText(str(var1))
            self.var2_ans_page3.setText(str(var2))
            self.var3_ans_page3.setText(str(var3))
            self.var4_ans_page3.setText(str(var4))
            self.var5_ans_page3.setText(str(var5))
            self.var6_ans_page3.setText(str(var6))

            self.next_page()

        except subprocess.CalledProcessError as e:
            print(f"Error running shell script: {e}")


    def do_simulate_btn(self, length, roadm_insertion_loss, BER):

        shell_script_path = 'test_simulate.sh'

        parameters = [length, roadm_insertion_loss, BER]

        try:
            print("hey")
            subprocess.run(['sh', shell_script_path] + parameters, check=True)

            results = []

            with open('result2.txt', 'r') as file:
                lines = file.readlines()

                for line in lines:
                    print(line)
                    values = line.split()

                    var1 = values[0]
                    var2 = values[1]
                    var3 = values[2]
                    var4 = values[3]
                    var5 = values[4]
                    var6 = values[5]

                    results.append([var1, var2, var3, var4, var5, var6])

                print(results)
                self.generate_page4_ui(self.page4_layout, results)
                print("out")
                self.page4.setLayout(self.page4_layout)

            self.next_page()
            self.next_page()

        except subprocess.CalledProcessError as e:
            print(f"Error running shell script: {e}")


    def next_page(self):
        current_index = self.stacked_widget.currentIndex()
        if current_index < self.stacked_widget.count() - 1:
            self.stacked_widget.setCurrentIndex(current_index + 1)

    def prev_page(self):
        current_index = self.stacked_widget.currentIndex()
        if current_index > 0:
            self.stacked_widget.setCurrentIndex(current_index - 1)

    def generate_page4_ui(self, layout, results):
        scroll_area = QScrollArea(self)
        # scroll_area.setWidgetResizable(True)
        scroll_area.setMinimumSize(400, 400)
        # Create a widget to hold the layout
        scroll_area.setWidget(QWidget())
        # scroll_area.setLayout(layout)

        # Clear existing widgets in the layout
        for i in reversed(range(layout.count())):
            layout.itemAt(i).widget().setParent(None)

        n = len(results)

        # Lists to store labels for each row
        boost_target_gain_ans_list = []
        numAmp_ans_list= []
        gOSNR_first_ans_list = []
        gOSNR_second_ans_list= []
        BER_first_ans_list=[]
        BER_second_ans_list=[]
        

        # Generate new widgets based on 'n' in a grid layout
        for i in range(n):
            label = QLabel(f"recommend {i + 1}:", self)
            boost_target_gain = QLabel(f"boost_target_gain :", self)
            numAmp = QLabel(f"numAmp:", self)
            gOSNR_first = QLabel(f"t1-gOSNR :", self)
            gOSNR_second = QLabel(f"t2-gOSNR :", self)
            BER_first = QLabel(f"t1-BER:", self)
            BER_second = QLabel(f"t2-BER:", self)
            # Create local variables for each label
            boost_target_gain_ans = QLabel("", self)
            numAmp_ans = QLabel("", self)
            gOSNR_first_ans = QLabel("", self)
            gOSNR_second_ans = QLabel("", self)
            BER_first_ans = QLabel("", self)
            BER_second_ans = QLabel("", self)

            # Add labels to the corresponding lists
            boost_target_gain_ans_list.append(boost_target_gain_ans )
            numAmp_ans_list.append(numAmp_ans)
            gOSNR_first_ans_list.append(gOSNR_first_ans)
            gOSNR_second_ans_list.append(gOSNR_second_ans )
            BER_first_ans_list.append(BER_first_ans)
            BER_second_ans_list.append(BER_second_ans)

            layout.addWidget(label, i, 0)
            layout.addWidget(boost_target_gain, i, 1)
            layout.addWidget(boost_target_gain_ans , i, 2)
            layout.addWidget(numAmp, i, 3)
            layout.addWidget(numAmp_ans, i, 4)
            layout.addWidget(gOSNR_first, i, 5)
            layout.addWidget(gOSNR_first_ans, i, 6)
            layout.addWidget(gOSNR_second, i, 7)
            layout.addWidget(gOSNR_second_ans, i, 8)
            layout.addWidget(BER_first, i, 9)
            layout.addWidget(BER_first_ans, i, 10)
            layout.addWidget(BER_second, i, 11)
            layout.addWidget(BER_second_ans, i, 12)

            # Set the text for each label
            boost_target_gain_ans.setText(results[i][0])
            numAmp_ans.setText(results[i][1])
            gOSNR_first_ans.setText(results[i][2])
            gOSNR_second_ans.setText(results[i][3])
            BER_first_ans.setText(results[i][4])
            BER_second_ans.setText(results[i][5])

        layout.addWidget(scroll_area)
        
if __name__ == '__main__':
    app = QApplication(sys.argv)
    calc_app = CalculatorApp()
    calc_app.show()
    sys.exit(app.exec_())
